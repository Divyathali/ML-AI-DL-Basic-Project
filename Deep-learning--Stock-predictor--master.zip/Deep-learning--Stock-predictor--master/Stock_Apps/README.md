## Descriptions:
Different types of options of predictions

__Input__  
1: Input the stock starting date  
2: Input the stock ending date  
3. Input the stock symbol  
4. Choose Algorithms for Stock Prediction  

