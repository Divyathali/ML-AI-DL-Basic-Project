# :large_blue_diamond: List of Algorithms :large_blue_diamond:  
:arrow_forward: AdaBoost Classification  
:arrow_forward: AdaBoost Regressor   
:arrow_forward: Anomaly Detection  
:arrow_forward: Artificial Neural Network   
:arrow_forward: Bagging Classifier   
:arrow_forward: Bayesian Ridge Regression  
:arrow_forward: Bernoulli Restricted Boltzmann Machine  
:arrow_forward: CatBoost Algorithms    
:arrow_forward: Classification Cluster  
:arrow_forward: Decision Tree Classification   
:arrow_forward: Decision Tree Regression  
:arrow_forward: Gradient Boosting Classification  
:arrow_forward: K-Means  
:arrow_forward: K-Nearest Neighbors  
:arrow_forward: Logistic Regression    
:arrow_forward: Linear Regression   
:arrow_forward: Nearest Neighbors  
:arrow_forward: NetworkX  
:arrow_forward: Neural Networks Regression  
:arrow_forward: Quantile Regression  
:arrow_forward: Partial Least Squares Regression (PLSR)  
:arrow_forward: Polynomial Regression    
:arrow_forward: Principal Component Classification  
:arrow_forward: Principal Component Regression  
:arrow_forward: Random Forest Classification  
:arrow_forward: Random Forest Regression   
:arrow_forward: RNN Tensorflow  
:arrow_forward: Ridge Regression  
:arrow_forward: Support Vector Machines (SVM)  
:arrow_forward: Tensorflow  
:arrow_forward: Time Series  
:arrow_forward: XGBoost  
