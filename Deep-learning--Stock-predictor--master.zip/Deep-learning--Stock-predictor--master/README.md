 ### Two types of problems: 
  1. Classification (predict label)  
  2. Regression (predict values)  
 
# Most Common Regression Algorithms  
1. Simple Linear Regression Model  
2. Logistic Regression  
3. Lasso Regression    
4. Support Vector Machines  
5. Polynomial Regression  
6. Stepwise Regression  
7. Ridge Regression  
8. Multivariate Regression Algorithm    
9. Multiple Regression Algorithm  
10. K Means Clustering Algorithm  
11. Naïve Bayes Classifier Algorithm  
12. Random Forests  
13. Decision Trees  
14. Nearest Neighbours   
15. Lasso Regression  
16. ElasticNet Regression  
17. Reinforcement Learning  
18. Artificial Intelligence    
19. MultiModal Network  
20. Biologic Intelligence  

# Prerequistes  
Python 3.5+  
Jupyter Notebook Python 3  
