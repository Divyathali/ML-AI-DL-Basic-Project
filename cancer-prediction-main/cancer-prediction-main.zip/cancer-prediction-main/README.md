# cancer-prediction

1.cancer_diagonosis_validation --> KNN based logistic algorithm - data Wrangling and visual based algorithm designed.
2.cancer_cell_prediction --> Linear regression based data/cell classification.
3.cancer based image classify --> onprogress..... 
