# ML-google-stock-predict

Machine learning- stock predicor( mini project).
Method - LSTM,liner regression.
lan - python.
dataset-link: yahoo-finance.


# Prerequistes  
Python 3.5+  
Jupyter Notebook Python 3  

